I have used the postcode API that can be found at https://getAddress.io.  The free service is limited to a maximum of 20 API calls per 24 hours; you may have to generate a new key to use the API.  You can get a new key at the bottom left of the page. This can then be copied into ex2.cfc at line 15/16 (You will see I have two keys in there already)

I started to do this using client side jQuery only, (faster!) but realised that was not using Coldfusion! I have now redone the code so the form submits to a CFC using the Coldfusion AJAX library.  The CFC simply parses the form variable into a URL, calls the getAddress.io API and returns the result to the browser.

Note - The parsing of the returned data is done on the client side.  A better solution would be to parse the return from getAddress.io in the CFC and return only cleaned results to the browser, but I am running out of time for this quiz! At this point a returned address could be stored in a coldfusion SESSION structure to keep the data available.

(However this API can often return multiple results for a single postcode, so it is neccesary to ask the user to confirm)

Also the UI is not very finished, such as the select menu does not clear for a new query. - of course this can be made a lot cleaner with data entered in form fields etc.

Also the submited data could be validated to prove a valid postcode - again, no time.

Test data:
No postcode given
Expected: Not permitted.
Result: pass 

Postcode dfgdghdg (garbage postcode)
Expected: no address found.
Result: pass 

Postcode G51 1QL (My own postcode)
House number: none
Expected: multiple results
Result: Pass, Addresses are correct.

Postcode G66 4UD (An Address known to me)
House number: none
Expected: multiple results
Result: Pass, Addresses are correct. Confirmed with google maps.

Postcode G66 4UD (An Address known to me)
House number: 109  (Correct)
Expected: one result
Result: Pass, Addresses is correct.

Postcode G66 4UD
House number: 999 (wrong)
Expected: Not found
Result: Pass

Postcode: OX4 4GE (Relayware)
House number: not given
Expected: one or more addresses
Result: Pass (note- application behaved correctly, but API is missing address)