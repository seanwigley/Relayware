I probably spent too much time on the jQuery for the interface on this excercise!

The broad idea is:
1) The user can enter a series of numbers (I have restricted these to integers, but no reason why any number cannot be used)
2) The created form is submitted to the cfc via Ajax POST
3) Coldfusion parses the form data to create an array
4) Coldfusion loops through the array comparing the sum before the current element to the sum after
5) If a match is found, the current index is stored in another array.
6) This array is returned to the calling function (as JSON string)
7) JSON is parsed and resulting array inspected
8) If pivots are present, these are displayed in the hidden div "rightPanel"
9) If no pivots, a "not found" message is displayed.

Known bugs:
If the user fails to press return after the last entry and clicks the button instead, the on change event is triggered instead of the click event.  This results in the user having to click again. Not acceptable in a live environment but I am leaving this for the purpose of this exercise, hope this is OK.  Too much time spent on jQuery already, should have just let the user submit a string!

Notes:
Form is restricted to integers, for speed. More complex validation could be used.
Commented out "alerts" through the code, I have left these in. For serious debugging console.log() would be used.
Minimal error checking in both the CFC and the Ajax function - again just for speed for the purpose of this excercise.

Test Data:

Array [1.5,1]
Expected: Not permitted.
Result: Pass

Array:  [1,1]
Expected: No pivot
Result: Pass

Array: [1,1,1]
Expected: Pivot at index 2
Result: Pass

Array [1,1,2]
Expected: no pivot
Result: Pass

Array: [-1,1,999,0]
Expected: pivot at index 3
Result: Pass

Array: [5,9,7,17,6,5,4,6]
Expected: pivot at index 4
Result: Pass

Array [-21,5,9,7,17,6,5,4,6,-21]
Expected: Pivot at index 5
Result: Pass

Array [-21,5,9,7,17,6,5,4,6,-22]
Expected: No Pivot 
Result: Pass

Array [-21,5,9,7,17,6,5,4,6,-22,1]
Expected: pivot at index 5 
Result: Pass